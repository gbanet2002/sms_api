package com.in28minutes.springboot.web.nbs03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nbs03Application {

	public static void main(String[] args) {
		SpringApplication.run(Nbs03Application.class, args);
	}

}
