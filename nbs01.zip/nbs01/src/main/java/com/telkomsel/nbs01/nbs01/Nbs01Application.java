package com.telkomsel.nbs01.nbs01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nbs01Application {

	public static void main(String[] args) {
		SpringApplication.run(Nbs01Application.class, args);
	}

}
